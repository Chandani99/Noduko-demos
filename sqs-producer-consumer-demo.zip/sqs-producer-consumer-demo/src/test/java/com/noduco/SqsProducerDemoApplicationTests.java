package com.noduco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SqsProducerDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
