package com.noduco.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.MessageHandler;
import org.springframework.messaging.MessagingException;
import org.springframework.stereotype.Service;

import com.amazonaws.services.sqs.AmazonSQSAsync;

import org.springframework.messaging.Message;

@Service
public class SQSMessageReceiver1  {

//    @Autowired
//    private AmazonSQSAsync amazonSQSAsync;
//
//  
//	@Override
//	public void handleMessage(Message message) throws MessagingException {
//		System.out.println(message.getHeaders());
//		
//	}
}
