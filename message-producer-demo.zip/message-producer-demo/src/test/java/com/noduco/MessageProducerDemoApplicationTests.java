package com.noduco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessageProducerDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
