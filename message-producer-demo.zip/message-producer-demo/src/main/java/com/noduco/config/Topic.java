package com.noduco.config;

public class Topic {
     public static final String OLD_MUSIC = "old-music";
     public static final String NEW_MUSIC = "new-music";
}
